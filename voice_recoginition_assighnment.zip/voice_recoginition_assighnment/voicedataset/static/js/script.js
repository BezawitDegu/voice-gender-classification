const dropZone = document.getElementById('drop-zone');
const fileInput = document.getElementById('file-input');
const fileNameDisplay = document.getElementById('file-name');
const analyzeBtn = document.getElementById('analyze-btn');
const loader = document.getElementById('loader');
const btnText = analyzeBtn.querySelector('.btn-text');
const resultCard = document.getElementById('result-card');

const topGender = document.getElementById('top-gender');
const topConfidence = document.getElementById('top-confidence');
const femalePercent = document.getElementById('female-percent');
const femaleFill = document.getElementById('female-fill');
const malePercent = document.getElementById('male-percent');
const maleFill = document.getElementById('male-fill');

let selectedFile = null;

// Handle Drag & Drop
dropZone.addEventListener('dragover', (e) => {
    e.preventDefault();
    dropZone.classList.add('dragging');
});

dropZone.addEventListener('dragleave', () => {
    dropZone.classList.remove('dragging');
});

dropZone.addEventListener('drop', (e) => {
    e.preventDefault();
    dropZone.classList.remove('dragging');
    if (e.dataTransfer.files.length > 0) {
        handleFile(e.dataTransfer.files[0]);
    }
});

// Handle Click to Browse
dropZone.addEventListener('click', () => fileInput.click());

fileInput.addEventListener('change', (e) => {
    if (e.target.files.length > 0) {
        handleFile(e.target.files[0]);
    }
});

function handleFile(file) {
    if (!file.type.startsWith('audio/')) {
        alert('Please select an audio file.');
        return;
    }
    selectedFile = file;
    fileNameDisplay.textContent = `Selected: ${file.name}`;
    analyzeBtn.disabled = false;
    resultCard.style.display = 'none';
}

// Analyze API Call
analyzeBtn.addEventListener('click', async () => {
    if (!selectedFile) return;

    // Reset UI
    analyzeBtn.disabled = true;
    loader.style.display = 'block';
    btnText.style.opacity = '0.5';
    resultCard.style.display = 'none';

    const formData = new FormData();
    formData.append('file', selectedFile);

    try {
        const response = await fetch('/predict-audio', {
            method: 'POST',
            body: formData
        });

        if (!response.ok) {
            const errorData = await response.json();
            throw new Error(errorData.detail || 'Analysis failed');
        }

        const data = await response.json();
        displayResults(data);

    } catch (error) {
        alert('Error: ' + error.message);
    } finally {
        analyzeBtn.disabled = false;
        loader.style.display = 'none';
        btnText.style.opacity = '1';
    }
});

function displayResults(data) {
    resultCard.style.display = 'block';
    
    // Top Result
    topGender.textContent = data.gender.charAt(0).toUpperCase() + data.gender.slice(1);
    topConfidence.textContent = (data.confidence * 100).toFixed(1) + '%';
    
    // Detailed Probabilities
    const fProb = (data.probabilities.female * 100).toFixed(1) + '%';
    const mProb = (data.probabilities.male * 100).toFixed(1) + '%';
    
    femalePercent.textContent = fProb;
    femaleFill.style.width = fProb;
    
    malePercent.textContent = mProb;
    maleFill.style.width = mProb;

    // Color code badge
    topConfidence.style.background = data.gender === 'female' ? '#ec4899' : '#3b82f6';
}
