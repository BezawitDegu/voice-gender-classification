import os
import base64
import io
import re
import traceback
from flask import Flask, request, jsonify
from flask_cors import CORS
from google import genai
from PIL import Image
from dotenv import load_dotenv

load_dotenv()

app = Flask(__name__)
CORS(app)

# API Key ን ከ Environment ማንበብ
api_key = os.getenv("GEMINI_API_KEY")
client = genai.Client(api_key=api_key, http_options={'api_version': 'v1'})

@app.route('/detect_currency', methods=['POST'])
def detect_currency():
    try:
        data = request.json
        if not data or 'image' not in data:
            return jsonify({"error": "No image"}), 400

        # ምስሉን ማዘጋጀት
        image_data = data.get('image', '').split(",")[1]
        image_bytes = base64.b64decode(image_data)
        img = Image.open(io.BytesIO(image_bytes))

        # ለ AIው ጠንካራ ትዕዛዝ መስጠት
        response = client.models.generate_content(
            model="gemini-2.0-flash", 
            contents=[
                "Analyze this image. Identify the value of the Ethiopian Birr note (5, 10, 50, 100, 200). Return ONLY the number. If no birr is seen, say Unknown.",
                img
            ]
        )
        
        raw_result = response.text.strip()
        print(f"AI ጥሬ ውጤት: {raw_result}")

        # ከጽሁፍ ውስጥ ቁጥር ብቻ ፈልጎ ማውጣት (ለምሳሌ "It is 100" ቢል 100ን ብቻ ይወስዳል)
        numbers = re.findall(r'\d+', raw_result)
        final_val = numbers[0] if numbers else "Unknown"
            
        print(f"የተለየው ዋጋ: {final_val}")
        return jsonify({"value": final_val})

    except Exception as e:
        error_msg = str(e)
        print(f"DEBUG ERROR: {error_msg}")
        if "429" in error_msg:
            return jsonify({"error": "Quota full. Wait 30s"}), 429
        return jsonify({"error": error_msg}), 500

if __name__ == "__main__":
    print("--- የብር መለያ ሰርቨር ተነስቷል (Port 5000) ---")
    app.run(port=5000)